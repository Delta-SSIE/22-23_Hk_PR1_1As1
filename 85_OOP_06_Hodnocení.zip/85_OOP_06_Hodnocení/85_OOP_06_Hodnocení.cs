﻿namespace _85_OOP_06_Hodnocení
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Student pavel = new Student("Pavel", "Novák", 1);
            Student petr = new Student("Petr", "Procházka", 2);
            Student anna = new Student("Anna", "Horáková", 4);



            pavel.PredstavSe();
            int znamka = pavel.JakaZnamna(); 
            Console.WriteLine("Pavel dostal z programování známku {0} {1}", znamka, pavel.ZhodnotitZnamku(znamka));
            Console.ReadKey();
            /*
            petr.PredstavSe();
            Console.WriteLine("Petrl dostal z programování známku 4. {0}", petr.ZhodnotitZnamku(5));
            Console.ReadKey();

            anna.PredstavSe();
            Console.WriteLine("Anicka dostala z programování známku 1. {0}", anna.ZhodnotitZnamku(1));*/
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _85_OOP_06_Hodnocení
{
    internal class Student
    {
        string jmeno;
        string prijmeni;
        int rocnik;

        // Konstruktor třídy Student

        public Student(string jmeno, string prijmeni, int rocnik)
        {
            this.jmeno = jmeno;
            this.prijmeni = prijmeni;
            this.rocnik = rocnik;

        }

        public void PredstavSe()
        {
            Console.WriteLine("Jmenuji se: {0} {1} a studuji v {2} ročníku.", jmeno, prijmeni, rocnik);
        }

        public int JakaZnamna()
        {
            Console.WriteLine("Jakou znamku dostal{0} z programovani?", jmeno);
            int znamka = int.Parse(Console.ReadLine());
            return znamka;
        }

        public string ZhodnotitZnamku(int znamka)
        {
            if ((znamka < 1) || (znamka > 5))
            {
                return "Takovou známku neznám!!";
            }

            if (rocnik > 1)
            { 
                if (znamka < 5)
                {
                    return "Hlavně, že to není nedostatečně";
                }
                else
                {
                    return "To není dobré, ale vždy se to dá zlepšit";
                }
                    
            }
            else
            {
                return "Zatím se rozkoukávám, co se ve škole děje";
            }

        }

    }
}

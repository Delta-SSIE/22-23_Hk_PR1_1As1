﻿namespace _89_get_set
{
    internal class Get_set_kruznice
    {
        static void Main(string[] args)
        {
           try
            { 
            Console.WriteLine("Zadej poloměr 1. kružnice");
                double parametr_polomer = (double.Parse(Console.ReadLine()));
                Kruznice k = new Kruznice(parametr_polomer);
                Console.WriteLine($"Kruznice o poloměru {k.Polomer} má obsah {k.Obsah}");
            }
            catch (Exception)
            {
                Console.WriteLine("Došlo k neočekávané chybě programu.");
            }
            try
            {
                Console.WriteLine("Zadej poloměr 2. kružnice");
                double parametr_polomer_2 = (double.Parse(Console.ReadLine()));
                Kruznice k = new Kruznice(parametr_polomer_2);
                Console.WriteLine($"Kruznice 2 o poloměru {k.Polomer} má obsah {k.Obsah}");
            }
            catch (Exception)
            {
                Console.WriteLine("Došlo k neočekávané chybě programu.");
            }
        }
    }
}
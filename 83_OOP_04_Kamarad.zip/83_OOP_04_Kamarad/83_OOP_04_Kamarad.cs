﻿namespace _83_OOP_04_Kamarad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Vytvoření lidí
            Clovek karel = new Clovek();
            karel.jmeno = "Karel Novák";
            karel.vek = 33;
           
            Clovek cyril = new Clovek();
            cyril.jmeno = "Cyril Nový";
            cyril.vek = 27;
           
            // Spřátelení
            karel.kamarad = cyril;
            cyril.kamarad = karel;
           
            // Představení
            karel.PredstavSe();
            cyril.PredstavSe();
            Console.ReadKey();
        }
    }
}
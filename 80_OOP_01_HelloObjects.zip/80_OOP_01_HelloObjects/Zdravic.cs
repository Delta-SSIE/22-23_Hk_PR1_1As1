﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _80_OOP_01_HelloObjects
{
    /// <summary>
    /// Třída reprezentuje zdravič, který slouží ke zdravení uživatelů
    /// </summary>

    internal class Zdravic
    {
        /// <summary>
        /// Text pozdravu - predávaný jako atribut
        /// </summary>
        public string text; // Definice atributu třídy Text datového typu sting

        /*  public void Pis_pozdrav()

          {
              Console.WriteLine("Ahoj světe");
          }*/

        /*public void Pis_pozdrav2(string jmeno) // Metoda s paramatrem ve tride Zdravic
        {
            Console.WriteLine("Ahoj uživateli {0}", jmeno);
        }*/
        /*
         public void Pis_pozdrav3(string jmeno) // Metoda s paramatrem ve tride Zdravic využivajici atribut třídy text
         {
             Console.WriteLine("{0} {1}",text, jmeno);
         }
        */

        // Metodu s návratovou hodnotou do Main

        /// <summary>
        /// Metoda pozdarví uživatele texten pozdravu a jeho jménem
        /// </summary>
        /// <param name="jmeno">Jméno uživatele</param>
        /// <returns>Text s pozdravem</returns>
        public string Pozdav4(string jmeno)
        {
            return String.Format("{0} {1}", text, jmeno);
        }
    }
}

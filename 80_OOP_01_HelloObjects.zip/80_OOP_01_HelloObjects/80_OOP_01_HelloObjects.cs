﻿namespace _80_OOP_01_HelloObjects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Zdravic pozdrav; // Vytvoření instabce třídy Zdravic s názven pozdrav
            pozdrav = new Zdravic(); // Volání konstruktoru nové instance
            */

            Zdravic pozdrav = new Zdravic();
            //pozdrav.Pis_pozdrav();
            //pozdrav.Pis_pozdrav2("Josef");
            //pozdrav.Pis_pozdrav2("Karel");

            /*pozdrav.text = "Ahoj uživateli"; // Naplnění atributu text třídy Zdravic
            pozdrav.Pis_pozdrav3("Josef");
            pozdrav.Pis_pozdrav3("Tomáš");
            pozdrav.text = "Vítám tě ve světě OOP";
            pozdrav.Pis_pozdrav3("\nJH");
            Console.WriteLine();*/

            pozdrav.text = "Ahoj uživateli";
            Console.WriteLine(pozdrav.Pozdav4("Karel")); // Voláme metodu Pozdrav4 ve tříádě Zravic, která nám vrací návratuvou hodnotu
            pozdrav.text = "Vítám tě ve světě OOP";
            Console.WriteLine(pozdrav.Pozdav4("\nJH"));
            Console.WriteLine();

        }
    }
}
﻿namespace _888_Krušnice_get_set
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Kruznice k = new Kruznice();
                Console.WriteLine("Zadej poloměr kuržnice");
                k.NastavPolomer(double.Parse(Console.ReadLine()));
                //Console.WriteLine(k._polomer);
                Console.WriteLine($"Obvod kružnice o poloměru {k.VratPolomer()} je {k.Obvod()}");
                Console.WriteLine($"Obsah kružnice o poloměru {k.VratPolomer()} je {k.Obsah()}");

            }
            catch (Exception)
            {
                Console.WriteLine("Došlo k neočekávané chybě programu.");
            }
        }
    }
}
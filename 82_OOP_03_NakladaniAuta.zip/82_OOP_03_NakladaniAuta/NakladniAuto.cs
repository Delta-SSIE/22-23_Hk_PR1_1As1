﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _82_OOP_03_NakladaniAuta
{    /// <summary>
     /// Reprezentuje nákladní auto
     /// </summary>
    internal class NakladniAuto
    {
        /// <summary>
        /// Nosnost
        /// </summary>
        public int nostnost = 3000;
        /// <summary>
        /// Hmotnost nákladu
        /// </summary>
        public int hmotnostNakladu = 0;

        /// <summary>
        /// Dotaz na velikost nákladu
        /// </summary>
        /// <param name="text">Formulace dotazu</param>
        /// <returns>Velikost nákladu v kg</returns>
        public int Dotaz(string text)
        {
            int naklad;
            Console.WriteLine($"\n" + text);
            while (!int.TryParse(Console.ReadLine(), out naklad))
            {
                Console.WriteLine("\nMá to být číslo.");
            }
            return naklad;
        }

        /// <summary>
        /// Pokusí se naložit náklad o dané hmotnosti
        /// </summary>
        /// <param name="hmotnost">Hmotnost nakládaného nákladu</param>
        public void Naloz(int hmotnost)
        {
            //Console.Clear();
            if (hmotnostNakladu + hmotnost <= nostnost)
            {
                hmotnostNakladu += hmotnost;
            }
            else
            {
                Console.WriteLine("Celková hmotnost nákladu je větší než NOSTNOST auta!");
            }

        }

        /// <summary>
        /// Pokusí se vyložit náklad o dané hmotnosti
        /// </summary>
        /// <param name="hmotnost">Hmotnost vykládaného nákladu</param>
        public void Vyloz(int hmotnost)
        {
            //Console.Clear();
            if (hmotnost <= hmotnostNakladu)
            {
                hmotnostNakladu -= hmotnost;
            }
            else
            {
                Console.WriteLine("Chceš vyložit více nákladu než JE naloženo!");
            }

        }

        /// <summary>
        /// Vypíše kolik je naloženo
        /// </summary>
        public void VypisNalozeni()
        {
            Console.WriteLine("\nV nákladním autě je naloženo {0} kg", hmotnostNakladu);
        }
    }
}

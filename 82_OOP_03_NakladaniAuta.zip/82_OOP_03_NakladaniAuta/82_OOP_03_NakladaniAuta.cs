﻿using static System.Net.Mime.MediaTypeNames;

namespace _82_OOP_03_NakladaniAuta
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NakladniAuto tatra = new NakladniAuto();
            string odpoved = "a";
            do
            {
                tatra.Naloz(tatra.Dotaz("Zadej hmotnost NAKLÁDANÉHO nákladu v kg:"));
                Console.WriteLine("Chceš další náklad? A/N");
                odpoved = Console.ReadKey().KeyChar.ToString().ToLower();
            } while (odpoved != "n");

            do
            {
                tatra.Vyloz(tatra.Dotaz("Zadej hmotnost VYKLÁDANÉHO nákladu  v kg:"));
                Console.WriteLine("Chceš další náklad? A/N");
                odpoved = Console.ReadKey().KeyChar.ToString().ToLower();
            } while (odpoved != "n");
           
            tatra.VypisNalozeni();
            Console.ReadKey();
        }

    }
}
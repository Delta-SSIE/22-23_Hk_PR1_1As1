﻿namespace _81_OOP_02_Kalkulacka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Vytvoření instance
            Kalkulacka kalkulacka = new Kalkulacka();

            Console.Write("Zadej 1. číslo: ");
            kalkulacka.cislo1 = double.Parse(Console.ReadLine());
            Console.Write("Zadej 2. číslo: ");
            kalkulacka.cislo2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Součet: {0}", kalkulacka.soucet());
            Console.WriteLine("Rozdíl: {0}", kalkulacka.rozdil());
            Console.WriteLine("Součin: {0}", kalkulacka.soucin());
            Console.WriteLine("Podíl: {0}", kalkulacka.podil());
            Console.ReadKey();
        }
    }
}
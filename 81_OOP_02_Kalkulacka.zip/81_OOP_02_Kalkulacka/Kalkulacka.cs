﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _81_OOP_02_Kalkulacka
{
    /// <summary>
    /// Třída reprezentuje kalkulačku, které se zadají 2 čísla a ona
    /// s nimi provádí základní aritmetické operace.
    /// </summary>
    internal class Kalkulacka
    {
        /// <summary>
        /// 1. číslo
        /// </summary>
        public double cislo1;
        /// <summary>
        /// 2. číslo
        /// </summary>
        public double cislo2;

        /// <summary>
        /// Vrací součet atributů
        /// </summary>
        /// <returns>Součet</returns>
        public double soucet()
        {
            return cislo1 + cislo2;
        }

        /// <summary>
        /// Vrací rozdíl atributů
        /// </summary>
        /// <returns>Rozdíl</returns>
        public double rozdil()
        {
            return cislo1 - cislo2;
        }

        /// <summary>
        /// Vrací součin atributů
        /// </summary>
        /// <returns>Součin</returns>
        public double soucin()
        {
            return cislo1 * cislo2;
        }

        /// <summary>
        /// Vrací podíl atributů
        /// </summary>
        /// <returns>Podíl</returns>
        public double podil()
        {
            return cislo1 / cislo2;
        }
    }
}
